CKEDITOR.editorConfig = function( config ) {
    config.fontSize_sizes = '16/16px;24/24px;48/48px;';
    config.font_names = 'Open Sans;Arial;Tahoma;Verdana';
};