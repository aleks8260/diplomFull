<?php 

// DB SETTINGS
define('DB_HOST', 'localhost');
define('DB_NAME', 'project-03');
define('DB_USER', 'root');
define('DB_PASS', '');

// SITE SETTINGS FOR EMAILS
define('SITE_NAME', 'личный сайт Юрия Ключевского');
define('SITE_EMAIL', 'info@webdev03.com');
define('ADMIN_EMAIL', 'info@rightblog.ru');

?>